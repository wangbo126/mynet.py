#client_1.py
import socket
import time

#host = socket.gethostname()
#port = 12345
addr = (socket.gethostname(),1234)
tcp_client_sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
tcp_client_sock.connect(addr)

#print(s.recv(1024).decode())
for data in ['Michael','Tracy','Sarah','exit']:
    time.sleep(.1)
    tcp_client_sock.send(data.encode())
    data = tcp_client_sock.recv(1024).decode()
    if data:
        print(data)
        continue
    tcp_client_sock.close()


#    print(s.recv(1024).decode())
#s.send('exit'.encode())
#s.close()

