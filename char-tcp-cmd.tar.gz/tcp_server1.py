#tcp_server1.py
import socket
import time
import threading

def tcp_link(sock,addr):
    print('Accept new connection from {}:{}'.format(*addr))
    sock.send('Welcome!'.encode())
    while True:
        data = sock.recv(1024).decode()
        #time.sleep(1)
        if data == 'exit' or not data:
            break
        sock.send('Hello,{}'.format(data).encode())
    sock.close()
    print('Connection from {}:{} closed.'.format(*addr))

def main():
    ADDR  = (socket.gethostname(),1234)
    tcp_server_sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    tcp_server_sock.bind(ADDR)
    tcp_server_sock.listen()
    print('Waiting for connection')

    while True:
        sock,addr = tcp_server_sock.accept()
        t = threading.Thread(target=tcp_link,args=(sock,addr))
        t.start()
    tcp_server_sock.close()

if __name__ == '__main__':
    main()



