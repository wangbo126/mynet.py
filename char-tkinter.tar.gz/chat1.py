import tkinter as tk
import threading
from socket import socket,AF_INET,SOCK_STREAM

class Chat:

    def __init__(self):
        self.sock = socket(AF_INET,SOCK_STREAM)
        self.sock.bind(('localhost',1234))
        self.sock.listen()
        self.extension_sock = None

        window = tk.Tk()
        window.title("Chat1")
        self.text = tk.Text(window)
        self.text.pack()

        self.text.insert(tk.END,('\t\t\t\t---------------\n\t\t\t\t '
            'Welcome to Chat \n\t\t\t\t '
            'Enjoy youself \n\t\t\t\t----------------\n\n\n\n'))
        frame = tk.Frame(window)
        frame.pack()

        label = tk.Label(frame,text="Enter your Message: ")
        self.message = tk.StringVar()

        entry_area = tk.Entry(frame,textvariable=self.message)
        send_button = tk.Button(frame,text="Send",command=self.send_message,bg='#40E0D0')
        label.grid(row=1,column=1)
        entry_area.grid(row=1,column=2)
        send_button.grid(row=1,column=4)

        thread = threading.Thread(target=self.handle)
        thread.start()

        window.mainloop()

    def send_message(self):
        message =self.message.get()
        if self.extension_sock:
            self.extension_sock.send(message.encode())
        self.text.insert(tk.END,"[Your Message] {}\n".format(message))

    def handle(self):
        extension_sock,addr = self.sock.accept()
        self.extension_sock = extension_sock
        while True:
            message = extension_sock.recv(1024).decode()
            self.text.insert(tk.END,'[Other\'s Message] {}\n'.format(message))


if __name__ == '__main__':
    Chat()


