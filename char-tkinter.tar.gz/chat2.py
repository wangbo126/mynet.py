import tkinter as tk
import threading
from socket import socket,AF_INET,SOCK_STREAM

class Chat:
    def __init__(self):
        window = tk.Tk()
        window.title("Chat2")
        self.text = tk.Text(window)
        self.text.pack()

        self.text.insert(tk.END,('\t\t\t\t---------------\n\t\t\t\t '
            'Welcome to Chat \n\t\t\t\t '
            'Enjoy youself \n\t\t\t\t----------------\n\n\n\n'))
        frame = tk.Frame(window)
        frame.pack()

        label = tk.Label(frame,text="Enter your Message: ")
        self.message = tk.StringVar()

        entry_area = tk.Entry(frame,textvariable=self.message)
        send_button = tk.Button(frame,text="Send",command=self.send_message,bg='#40E0D0')
        link_button = tk.Button(window,text='Link',command=self.link_chat,bg='#40E0D0')
        link_button.pack()

        label.grid(row=1,column=1)
        entry_area.grid(row=1,column=2)
        send_button.grid(row=1,column=4)

        window.mainloop()

    def send_message(self):
        message = self.message.get()
        self.sock.send(message.encode())
        self.text.insert(tk.END,"[Your Message] {}\n".format(message))

    def link_chat(self):
        self.sock = socket(AF_INET,SOCK_STREAM)
        addr = ('localhost',1234)

        self.sock.connect(addr)
        self.text.insert(tk.END,'Linked success\n')

        thread = threading.Thread(target=self.handle)
        thread.start()

    def handle(self):
        while True:
            message = self.sock.recv(1024).decode()
            self.text.insert(tk.END,'[Other\'s Message] {}\n'.format(message))


if __name__ == '__main__':
    Chat()


